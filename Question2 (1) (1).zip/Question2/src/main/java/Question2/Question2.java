package Question2;

import java.util.ArrayList;
import java.util.Scanner;

public class Question2 {

    public static void main(String[] args) {
        
       Scanner sc = new Scanner(System.in);
       System.out.println("WELCOME, WOULD YOU LIKE TO LOGIN OR CREATE A NEW ACCOUNT?\n(L) - Login\n(C) - Create new account");
       String loginOrNewAccount = sc.next();
       
       switch(loginOrNewAccount){
           
           case "L":break;
           case "C":
               
               
               System.out.println("Please enter in username>");
               String inputUsername = sc.next();
               
               System.out.println("Please enter in password>");
               String inputPassword= sc.next();
               
               while(passCheck(inputPassword)==false){
                   
                   System.out.println("Invalid Password!");
                   System.out.println("Please enter in password>");
                   inputPassword= sc.next();
                   
               
               }
               
               System.out.println("Please enter in fullname>");
               String inputFullName = sc.next();
               
               System.out.println("Please enter in your cell number>");
               String inputCellNum = sc.next();
               
               
  
               createNewAcc(inputUsername, inputPassword, inputFullName, inputCellNum);
               
               
               
               break;
       
       }
    }
    
    public static void createNewAcc(String username, String password, String name, String cell){
        
        ArrayList<String> uName = new ArrayList<String>();
        ArrayList<String> pass = new ArrayList<String>();
        ArrayList<String> fullName = new ArrayList<String>();
        ArrayList<String> phone = new ArrayList<String>();
        
        uName.add(username);
        pass.add(password);
        fullName.add(name);
        phone.add(cell);
        
        String dataForFile = "Username: " + uName.toString()
                +"\n Password: " + pass.toString()
                +"\n FullName: " + fullName.toString()
                +"\n Phone: " + phone.toString();
        
        createTextFile file = new createTextFile(dataForFile,"users.txt");
        file.setData(dataForFile);
        file.setFileName("users.txt");
        
        System.out.println("User capture successfully and text file of details created!");
    
    }
    public static boolean passCheck(String password){
        
        boolean valid = false;
        
        for (int i = 0; i < password.length(); i++) {
            
            if(Character.isDigit(password.charAt(i))){
                
                valid = true; //checking if password has numbers
            
            
            }
            
            
            
        }
        
        return valid;
    
    }
}
