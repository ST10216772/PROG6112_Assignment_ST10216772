package Question2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class createTextFile {
    
    private String data;
    private String fileName;
    
    public createTextFile(String inData,String infileName){
        
        data = inData;
        fileName = infileName;
    
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getFileName() {
        return fileName;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    public static void writeToFile(String fileName, String data) throws IOException{
        
        
      File myObj = new File(fileName);
      if (myObj.createNewFile()) {
        System.out.println("File created: " + myObj.getName());
      }
      
      FileWriter myWriter = new FileWriter(fileName);
      myWriter.write(data);
      myWriter.close();
      System.out.println("Details have been written to file");
     }
    }
    
    
    

